
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

const birdImg = new Image();
birdImg.src = "macchar.png";

let frames = 0;

const state = {
  current: 0,
  getReady: 0,
  game: 1,
  over: 2
};

canvas.addEventListener("click", function () {
  switch (state.current) {
    case state.getReady:
      state.current = state.game;
      break;
    case state.game:
      bird.flap();
      break;
    case state.over:
      location.reload();
      break;
  }
});

const bird = {
  x: 50,
  y: 150,
  width: 34,
  height: 24,
  gravity: 0.25,
  jump: 4.6,
  speed: 0,

  draw: function () {
    ctx.drawImage(birdImg, this.x, this.y, this.width, this.height);
  },

  flap: function () {
    this.speed = -this.jump;
  },

  update: function () {
    if (state.current === state.getReady) {
      this.y = 150;
    } else {
      this.speed += this.gravity;
      this.y += this.speed;

      if (this.y + this.height >= canvas.height) {
        this.y = canvas.height - this.height;
        if (state.current === state.game) {
          state.current = state.over;
        }
      }
    }
  }
};

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  bird.draw();
}

function update() {
  bird.update();
}

function loop() {
  update();
  draw();
  frames++;
  requestAnimationFrame(loop);
}

loop();
